const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');
const path = require('path');

const app = express();
const port = 9091;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MongoDB Connection
const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

let db;

async function connectToMongoDB() {
    try {
        await client.connect();
        console.log("Connected to MongoDB");

        db = client.db("ecommers");
    } catch (err) {
        console.error("Error connecting to MongoDB", err);
    }
}

connectToMongoDB();
app.use(express.static('public'));
app.use(express.static(__dirname+'/public'));

app.get(["/index.html","/index.html#product-cards"],(req,res)=>{
    res.sendFile(__dirname + '/index.html');
})

app.get("/about.html",(req,res)=>{
    res.sendFile(__dirname+'/about.html');
})

app.get('/contact.html',(req,res)=>{

    res.sendFile(__dirname+'/contact.html');
})


app.get('/login.html',(req,res)=>{
    res.sendFile(__dirname+'/login.html');
})

app.get('/register.html',(req,res)=>{
    res.sendFile(__dirname+'/register.html');
})

app.get('/add-to-cart.html',(req,res)=>{
    res.sendFile(__dirname+'/add-to-cart.html');
})

app.get('/payment.html',(req,res)=>{
    res.sendFile(__dirname+'/payment.html');
})
app.get('/frount.html',(req,res)=>{
    res.sendFile(__dirname+'/frount.html');
})
app.get('/email.html',(req,res)=>{
    res.sendFile(__dirname+'/email.html');
})




app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        const usersCollection = db.collection('users'); 
        const existingUser = await usersCollection.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ error: "User already exists" });
        }
        await usersCollection.insertOne({ username, password });
        res.status(201).json({ message: "User created successfully" });
    } catch (error) {
        console.error("Error signing up:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const usersCollection = db.collection('users');
        const user = await usersCollection.findOne({ username, password });
        if (user) {
            res.status(200).json({ message: "Login successful" });
        } else {
            res.status(401).json({ error: "Invalid credentials" });
        }
    } catch (error) {
        console.error("Error logging in:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});